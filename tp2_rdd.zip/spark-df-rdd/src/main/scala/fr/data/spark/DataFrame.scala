package fr.data.spark

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.log4j._

object DataFrame {

  def parsLine(line: String) = {
    val fields = line.split(";")
    val code_commune = fields(1).toInt
    val nom = fields(2).toString
    val code_postal = fields(3).toInt
    val ligne_5 = fields(4).toString
    val libellé_acheminement = fields(5).toString
    val coordonnees_gps = fields(6).toInt

    (code_commune,nom,code_postal,ligne_5,libellé_acheminement,coordonnees_gps)
  }
  import org.apache.spark.sql.SparkSession

  def main(args: Array[String]): Unit = {

    val  sc = new SparkContext("local[*]","DataFrame")

    val df = sc.textFile("/Users/thomasnoirclerc/Downloads/spark-df/src/main/resources/codesPostaux.csv")

    val rdd = df.map(parsLine)

    println(rdd)


    val exo1 = rdd.collect().foreach(println)
    println(exo1)


    val exo2 = rdd.flatMap(_._2).count()

    val exo3 = rdd.flatMap()


  }
}
