package fr.data.spark

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._


object DataFrame {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("DataFrame")
      .config("spark.master", "local")
      .getOrCreate()



    val df = spark.read.csv("/Users/thomasnoirclerc/Downloads/spark-df 2/src/main/resources/codesPostaux.csv")

    val df2 = df.select(
      split(col("_c0"),";").getItem(0).as("Code_commune_INSEE"),
      split(col("_c0"),";").getItem(1).as("Nom_commune"),
      split(col("_c0"),";").getItem(2).as("Code_postal"),
      split(col("_c0"),";").getItem(3).as("Ligne_5"),
      split(col("_c0"),";").getItem(4).as("Libellé_d_acheminement"),
      split(col("_c0"),";").getItem(5).as("coordonnees_gps"))
      .drop("_c0")

    df2.show()
    df2.printSchema()
    df2.groupBy("Nom_commune").count().show()

    val df3 = df2.select(
      split(col("Code_commune_INSEE"),"").getItem(0).as("1"),
      split(col("Code_commune_INSEE"),"").getItem(1).as("2")).drop("Code_commune_INSEE")
    df3.show()


    val df4 = df3.select(concat(col("1"),
      col("2")).as("code_departement"))
    df4.show()

    val df5 = df2.join(df4)
    df5.show()











  }

}
